import { motion } from 'framer-motion';

const Philosophy = () => {
  return (
    <section className="py-24 bg-gradient-to-b from-white to-rose-50/30 overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-rose-500 font-medium tracking-[0.3em] uppercase mb-6 block text-xs">
              From the Founder
            </span>
            <h2 className="text-3xl md:text-5xl font-serif text-neutral-900 leading-tight mb-10">
              "I made one product, <br />
              and I made it <span className="italic">perfect</span>."
            </h2>
            <div className="w-12 h-px bg-rose-300 mx-auto mb-10"></div>
            <p className="text-neutral-600 text-lg leading-relaxed mb-6 max-w-2xl mx-auto">
              For three years, Kyff Patra obsessed over a single formula. No collections, no constant launches — just one skin tint, reformulated 47 times, tested on 1,200 faces across every undertone, until it was undeniable.
            </p>
            <p className="text-neutral-500 leading-relaxed max-w-2xl mx-auto">
              Luminous Veil™ is the result. A skin tint that does the work of foundation, serum, primer, and SPF — without the weight of any of them. Because you deserve one product that just <em>works</em>.
            </p>
            <p className="mt-10 font-serif text-2xl italic text-neutral-700">— Kyff Patra</p>
            <p className="text-xs tracking-[0.3em] uppercase text-neutral-400 mt-2">Founder & Formulator</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;
