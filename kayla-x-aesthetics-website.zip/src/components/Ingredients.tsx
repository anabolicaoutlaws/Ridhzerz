import { motion } from 'framer-motion';

const ingredients = [
  { name: "Hyaluronic Acid", description: "Deeply hydrates and plumps for a youthful glow.", icon: "💧" },
  { name: "Vitamin C", description: "Brightens skin tone and provides antioxidant protection.", icon: "✨" },
  { name: "Rosehip Oil", description: "Calms inflammation and promotes skin regeneration.", icon: "🌹" },
  { name: "Squalane", description: "Mimics skin's natural oils to lock in moisture.", icon: "🍃" }
];

const Ingredients = () => {
  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-4 md:px-8 text-center">
        <span className="text-rose-500 font-medium tracking-[0.3em] uppercase mb-4 block text-xs">The Kare Standard</span>
        <h2 className="text-4xl md:text-5xl font-serif text-neutral-900 mb-16">Formulated with Care</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {ingredients.map((ing, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="p-8 border border-neutral-100 hover:border-rose-100 hover:bg-rose-50/30 transition-all duration-500 group"
            >
              <div className="text-4xl mb-6 grayscale group-hover:grayscale-0 transition-all duration-500">{ing.icon}</div>
              <h3 className="text-lg font-medium text-neutral-800 mb-3">{ing.name}</h3>
              <p className="text-neutral-500 text-sm leading-relaxed">{ing.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Ingredients;
