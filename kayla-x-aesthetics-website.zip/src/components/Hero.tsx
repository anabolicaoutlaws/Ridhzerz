import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-screen w-full overflow-hidden flex items-center bg-gradient-to-br from-rose-50 via-orange-50/40 to-amber-50/30 pt-32 pb-16">
      {/* Decorative blurred circles */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-rose-200/30 rounded-full blur-3xl"></div>
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-amber-200/30 rounded-full blur-3xl"></div>

      <div className="container mx-auto px-4 md:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, ease: 'easeOut' }}
          >
            <span className="text-rose-500 font-medium tracking-[0.3em] uppercase mb-6 block text-xs">
              The Signature Product
            </span>
            <h2 className="text-5xl md:text-7xl lg:text-8xl font-serif text-neutral-900 leading-[0.95] mb-8">
              Skin so good, <br />
              <span className="italic text-rose-500">it's barely there.</span>
            </h2>
            <p className="text-neutral-600 text-lg md:text-xl mb-8 max-w-lg leading-relaxed">
              Meet <strong className="text-neutral-900">Luminous Veil™</strong> — our weightless skin tint that blurs imperfections while letting your natural glow shine through. Available in 24 shades.
            </p>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-10">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-rose-400 text-rose-400" />
                ))}
              </div>
              <span className="text-sm text-neutral-600">4.9 · 2,847 reviews</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#product"
                className="bg-neutral-900 text-white px-10 py-4 text-sm tracking-widest uppercase hover:bg-neutral-800 transition-all duration-300 text-center"
              >
                Shop Skin Tint — $42
              </a>
              <a
                href="#shades"
                className="border border-neutral-900 text-neutral-900 px-10 py-4 text-sm tracking-widest uppercase hover:bg-neutral-900 hover:text-white transition-all duration-300 text-center"
              >
                Find Your Shade
              </a>
            </div>

            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-xs tracking-widest uppercase text-neutral-500">
              <span>✓ Vegan</span>
              <span>✓ Cruelty-Free</span>
              <span>✓ SPF 30</span>
              <span>✓ 16hr Wear</span>
            </div>
          </motion.div>

          {/* Right: Product Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, ease: 'easeOut', delay: 0.2 }}
            className="relative"
          >
            <div className="relative aspect-[4/5] overflow-hidden">
              <img
                src="/skin-tint-hero.jpg"
                alt="Luminous Veil Skin Tint"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating badge */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -bottom-6 -left-6 bg-white shadow-xl rounded-full w-32 h-32 flex flex-col items-center justify-center text-center"
            >
              <span className="text-[9px] tracking-[0.2em] uppercase text-neutral-500">Best</span>
              <span className="font-serif text-2xl text-neutral-900 italic">Seller</span>
              <span className="text-[9px] tracking-[0.2em] uppercase text-neutral-500">2026</span>
            </motion.div>
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute top-8 -right-4 bg-rose-500 text-white rounded-full px-6 py-3 shadow-lg"
            >
              <span className="text-xs tracking-widest uppercase font-medium">New Shade Drop</span>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
