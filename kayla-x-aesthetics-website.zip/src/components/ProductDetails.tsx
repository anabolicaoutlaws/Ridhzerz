import { motion } from 'framer-motion';
import { Droplets, Sun, Sparkles, Leaf, Clock, Heart } from 'lucide-react';

const benefits = [
  { icon: Droplets, title: 'Hydrating', desc: 'Hyaluronic acid plumps and quenches for 24-hour moisture.' },
  { icon: Sun, title: 'SPF 30 Protection', desc: 'Mineral sunscreen shields without a white cast.' },
  { icon: Sparkles, title: 'Buildable Coverage', desc: 'Sheer to medium — your skin, only better.' },
  { icon: Clock, title: '16-Hour Wear', desc: 'Comfortable, transfer-resistant, all-day finish.' },
  { icon: Leaf, title: 'Skin-Loving', desc: 'Niacinamide, squalane, and vitamin E nourish as you wear.' },
  { icon: Heart, title: 'Clean & Vegan', desc: 'Cruelty-free, dermatologist-tested, and gentle on skin.' },
];

const ProductDetails = () => {
  return (
    <section id="product" className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          {/* Image */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="aspect-[4/5] overflow-hidden">
              <img
                src="/skin-tint-model.jpg"
                alt="Model wearing Luminous Veil Skin Tint"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-rose-500 font-medium tracking-[0.3em] uppercase mb-4 block text-xs">
              The Product
            </span>
            <h2 className="text-4xl md:text-6xl font-serif text-neutral-900 mb-6 leading-tight">
              Luminous <span className="italic">Veil™</span> <br />
              Skin Tint
            </h2>
            <p className="text-neutral-600 text-lg leading-relaxed mb-6">
              A radiant, second-skin tint that does what foundation can't — blurs, brightens, and breathes. Formulated with 72% skincare actives, it's the only complexion product you'll ever need.
            </p>
            <p className="text-neutral-500 italic mb-8 border-l-2 border-rose-300 pl-4">
              "I wanted to create something my clients could wear from yoga to dinner — no touch-ups, no stress. Just skin." — Kyff Patra
            </p>

            <div className="flex items-baseline gap-4 mb-8">
              <span className="text-4xl font-serif text-neutral-900">$42</span>
              <span className="text-sm text-neutral-400 line-through">$52</span>
              <span className="text-xs tracking-widest uppercase text-rose-500 bg-rose-50 px-3 py-1">Launch Offer</span>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="bg-neutral-900 text-white px-10 py-4 text-sm tracking-widest uppercase hover:bg-neutral-800 transition-all flex-1">
                Add to Bag
              </button>
              <button className="border border-neutral-900 text-neutral-900 px-10 py-4 text-sm tracking-widest uppercase hover:bg-neutral-50 transition-all">
                ♡
              </button>
            </div>

            <p className="text-xs text-neutral-400 tracking-wider uppercase mt-6">
              Free shipping over $100 · 30-day returns
            </p>
          </motion.div>
        </div>

        {/* Benefits Grid */}
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-serif text-neutral-900 mb-4">
            Why you'll <span className="italic">love it</span>
          </h3>
          <p className="text-neutral-500">Six reasons it's about to become your everyday ritual.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              className="p-8 border border-neutral-100 hover:border-rose-200 hover:bg-rose-50/20 transition-all duration-500 group"
            >
              <benefit.icon className="text-rose-400 mb-5 group-hover:scale-110 transition-transform" size={28} strokeWidth={1.5} />
              <h4 className="text-lg font-medium text-neutral-900 mb-2">{benefit.title}</h4>
              <p className="text-neutral-500 text-sm leading-relaxed">{benefit.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProductDetails;
