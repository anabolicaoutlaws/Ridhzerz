import { useState, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X, User } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      {!isScrolled && (
        <div className="bg-neutral-900 text-white text-[10px] py-2 text-center tracking-[0.2em] uppercase font-light">
          Launch offer · Luminous Veil™ Skin Tint now $42 · Free shipping over $100
        </div>
      )}
      <div className="container mx-auto px-4 md:px-8 mt-4">
        <div className="flex items-center justify-between">
          <div className="hidden md:flex space-x-8">
            <a href="#product" className="text-sm uppercase tracking-widest hover:text-rose-500 transition-colors">The Tint</a>
            <a href="#shades" className="text-sm uppercase tracking-widest hover:text-rose-500 transition-colors">Shades</a>
            <a href="#about" className="text-sm uppercase tracking-widest hover:text-rose-500 transition-colors">About</a>
          </div>

          <div className="text-center">
            <h1 className={`text-2xl md:text-3xl font-serif tracking-tighter ${isScrolled ? 'text-neutral-900' : 'text-neutral-900'}`}>
              KAYLA <span className="font-light italic text-rose-400">X</span> AESTHETICS
            </h1>
            <p className="text-[8px] tracking-[0.3em] uppercase opacity-60">By Kyff Patra</p>
          </div>

          <div className="flex items-center space-x-5">
            <button className="hover:text-rose-500 transition-colors"><Search size={20} /></button>
            <button className="hover:text-rose-500 transition-colors hidden md:block"><User size={20} /></button>
            <button className="relative hover:text-rose-500 transition-colors">
              <ShoppingBag size={20} />
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] rounded-full w-4 h-4 flex items-center justify-center">0</span>
            </button>
            <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white absolute top-full left-0 w-full border-t border-neutral-100 py-6 px-8 flex flex-col space-y-4 animate-in fade-in slide-in-from-top-4">
          <a href="#product" className="text-lg font-light tracking-wide">The Skin Tint</a>
          <a href="#shades" className="text-lg font-light tracking-wide">Find Your Shade</a>
          <a href="#about" className="text-lg font-light tracking-wide">Our Story</a>
          <a href="#reviews" className="text-lg font-light tracking-wide">Reviews</a>
        </div>
      )}
    </header>
  );
};

export default Header;
