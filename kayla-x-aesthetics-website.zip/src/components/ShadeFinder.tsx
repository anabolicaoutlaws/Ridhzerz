import { useState } from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

const shades = [
  // Fair
  { name: '01 Porcelain', hex: '#F5DCC4', family: 'Fair', undertone: 'Cool' },
  { name: '02 Ivory', hex: '#F0D2B6', family: 'Fair', undertone: 'Neutral' },
  { name: '03 Shell', hex: '#EBC8A8', family: 'Fair', undertone: 'Warm' },
  { name: '04 Linen', hex: '#E4BE9A', family: 'Fair', undertone: 'Neutral' },
  // Light
  { name: '05 Beige', hex: '#D9B189', family: 'Light', undertone: 'Warm' },
  { name: '06 Sand', hex: '#D2A77E', family: 'Light', undertone: 'Neutral' },
  { name: '07 Buff', hex: '#CB9D72', family: 'Light', undertone: 'Warm' },
  { name: '08 Almond', hex: '#C29368', family: 'Light', undertone: 'Cool' },
  // Medium
  { name: '09 Honey', hex: '#B8895F', family: 'Medium', undertone: 'Warm' },
  { name: '10 Caramel', hex: '#AE7F56', family: 'Medium', undertone: 'Neutral' },
  { name: '11 Amber', hex: '#A4754D', family: 'Medium', undertone: 'Warm' },
  { name: '12 Toffee', hex: '#996B45', family: 'Medium', undertone: 'Cool' },
  // Tan
  { name: '13 Hazel', hex: '#8E613D', family: 'Tan', undertone: 'Neutral' },
  { name: '14 Cinnamon', hex: '#825836', family: 'Tan', undertone: 'Warm' },
  { name: '15 Chestnut', hex: '#774F30', family: 'Tan', undertone: 'Cool' },
  { name: '16 Maple', hex: '#6B4729', family: 'Tan', undertone: 'Warm' },
  // Deep
  { name: '17 Mocha', hex: '#5F3F23', family: 'Deep', undertone: 'Neutral' },
  { name: '18 Espresso', hex: '#53371E', family: 'Deep', undertone: 'Cool' },
  { name: '19 Cocoa', hex: '#473019', family: 'Deep', undertone: 'Warm' },
  { name: '20 Walnut', hex: '#3D2916', family: 'Deep', undertone: 'Neutral' },
  // Rich
  { name: '21 Truffle', hex: '#352311', family: 'Rich', undertone: 'Cool' },
  { name: '22 Onyx', hex: '#2D1D0E', family: 'Rich', undertone: 'Warm' },
  { name: '23 Obsidian', hex: '#25180B', family: 'Rich', undertone: 'Neutral' },
  { name: '24 Midnight', hex: '#1D1308', family: 'Rich', undertone: 'Cool' },
];

const families = ['All', 'Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'];

const ShadeFinder = () => {
  const [selectedShade, setSelectedShade] = useState(shades[8]);
  const [filter, setFilter] = useState('All');

  const filteredShades = filter === 'All' ? shades : shades.filter((s) => s.family === filter);

  return (
    <section id="shades" className="py-24 bg-neutral-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <span className="text-rose-500 font-medium tracking-[0.3em] uppercase mb-4 block text-xs">
            Find Your Match
          </span>
          <h2 className="text-4xl md:text-5xl font-serif text-neutral-900 mb-6">
            24 shades. <span className="italic">Made for everyone.</span>
          </h2>
          <p className="text-neutral-500 leading-relaxed">
            From porcelain to midnight — every undertone, every story. Our extensive shade range was developed with Kyff Patra to celebrate every skin tone.
          </p>
        </div>

        {/* Filter */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {families.map((fam) => (
            <button
              key={fam}
              onClick={() => setFilter(fam)}
              className={`px-5 py-2 text-xs tracking-[0.2em] uppercase border transition-all duration-300 ${
                filter === fam
                  ? 'bg-neutral-900 text-white border-neutral-900'
                  : 'bg-transparent text-neutral-600 border-neutral-300 hover:border-neutral-900'
              }`}
            >
              {fam}
            </button>
          ))}
        </div>

        {/* Shade Grid */}
        <motion.div
          layout
          className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-12 gap-3 max-w-5xl mx-auto mb-16"
        >
          {filteredShades.map((shade) => (
            <button
              key={shade.name}
              onClick={() => setSelectedShade(shade)}
              className="relative group aspect-square rounded-full transition-transform hover:scale-110"
              style={{ backgroundColor: shade.hex }}
              title={shade.name}
            >
              {selectedShade.name === shade.name && (
                <span className="absolute inset-0 flex items-center justify-center">
                  <Check size={20} className="text-white drop-shadow-lg" strokeWidth={3} />
                </span>
              )}
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[9px] text-neutral-500 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                {shade.name.split(' ')[0]}
              </span>
            </button>
          ))}
        </motion.div>

        {/* Selected Shade Display */}
        <motion.div
          key={selectedShade.name}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 md:p-12 max-w-3xl mx-auto flex flex-col md:flex-row items-center gap-8 shadow-sm"
        >
          <div
            className="w-32 h-32 rounded-full flex-shrink-0 shadow-inner"
            style={{ backgroundColor: selectedShade.hex }}
          ></div>
          <div className="text-center md:text-left flex-1">
            <p className="text-xs tracking-[0.3em] uppercase text-rose-500 mb-2">Your Shade</p>
            <h3 className="text-3xl font-serif text-neutral-900 mb-2">{selectedShade.name}</h3>
            <p className="text-neutral-500 mb-6">
              {selectedShade.family} skin · {selectedShade.undertone} undertone
            </p>
            <button className="bg-neutral-900 text-white px-8 py-3 text-xs tracking-widest uppercase hover:bg-neutral-800 transition-all">
              Add to Bag — $42
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ShadeFinder;
