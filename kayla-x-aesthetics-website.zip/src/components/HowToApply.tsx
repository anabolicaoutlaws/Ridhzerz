import { motion } from 'framer-motion';

const steps = [
  {
    num: '01',
    title: 'Prep',
    desc: 'Start with clean, moisturized skin. Apply your favorite serum and let it absorb.',
  },
  {
    num: '02',
    title: 'Drop',
    desc: 'Dispense 2-3 drops onto the back of your hand. A little goes a long way.',
  },
  {
    num: '03',
    title: 'Blend',
    desc: 'Press into skin with fingertips or a damp sponge. Build coverage where you need it.',
  },
  {
    num: '04',
    title: 'Glow',
    desc: "That's it. No setting powder needed. Skin looks lit-from-within all day.",
  },
];

const HowToApply = () => {
  return (
    <section className="py-24 bg-neutral-900 text-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="relative order-2 lg:order-1"
          >
            <div className="aspect-square overflow-hidden">
              <img
                src="/skin-tint-texture.jpg"
                alt="Skin tint texture"
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          <div className="order-1 lg:order-2">
            <span className="text-rose-400 font-medium tracking-[0.3em] uppercase mb-4 block text-xs">
              The Ritual
            </span>
            <h2 className="text-4xl md:text-5xl font-serif mb-12 leading-tight">
              Four steps to <span className="italic">effortless glow</span>
            </h2>

            <div className="space-y-8">
              {steps.map((step, idx) => (
                <motion.div
                  key={step.num}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.15 }}
                  className="flex gap-6 border-b border-neutral-800 pb-6"
                >
                  <span className="font-serif text-3xl text-rose-400 italic">{step.num}</span>
                  <div>
                    <h4 className="text-xl font-medium mb-2">{step.title}</h4>
                    <p className="text-neutral-400 leading-relaxed">{step.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowToApply;
