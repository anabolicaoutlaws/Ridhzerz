import { Camera, Share2, Globe, ArrowRight } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-neutral-900 text-neutral-300 pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div className="col-span-1 lg:col-span-1">
            <h3 className="text-white text-xl font-serif mb-6 tracking-tighter">
              KAYLA <span className="italic text-rose-400">X</span> AESTHETICS
            </h3>
            <p className="text-sm leading-relaxed mb-8 opacity-70">
              Redefining luxury beauty through curated aesthetics and high-performance formulas by Kyff Patra.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-rose-400 transition-colors"><Camera size={20} /></a>
              <a href="#" className="hover:text-rose-400 transition-colors"><Share2 size={20} /></a>
              <a href="#" className="hover:text-rose-400 transition-colors"><Globe size={20} /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white text-xs tracking-[0.2em] uppercase mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Shop All</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Our Story</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white text-xs tracking-[0.2em] uppercase mb-6">The Skin Tint</h4>
            <ul className="space-y-4 text-sm">
              <li><a href="#shades" className="hover:text-white transition-colors">All 24 Shades</a></li>
              <li><a href="#product" className="hover:text-white transition-colors">Ingredients</a></li>
              <li><a href="#" className="hover:text-white transition-colors">How to Apply</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Shade Matching</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white text-xs tracking-[0.2em] uppercase mb-6">Newsletter</h4>
            <p className="text-sm opacity-70 mb-6">Subscribe to receive beauty tips and early access to launches.</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="Email Address" 
                className="w-full bg-transparent border-b border-neutral-700 py-3 pr-10 text-sm focus:outline-none focus:border-rose-400 transition-colors"
              />
              <button className="absolute right-0 top-1/2 -translate-y-1/2 hover:text-rose-400 transition-colors">
                <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-neutral-800 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:y-0">
          <p className="text-[10px] tracking-[0.1em] uppercase opacity-50">
            © 2024 KAYLA X AESTHETICS BY KYFF PATRA. ALL RIGHTS RESERVED.
          </p>
          <div className="flex space-x-6 text-[10px] tracking-[0.1em] uppercase opacity-50">
            <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
