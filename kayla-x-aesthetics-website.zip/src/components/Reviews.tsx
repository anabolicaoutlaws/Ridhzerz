import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const reviews = [
  {
    name: 'Amara J.',
    shade: 'Shade 17 Mocha',
    rating: 5,
    title: 'Finally — a tint that matches me.',
    text: "I've tried every skin tint on the market and this is the first one that doesn't oxidize on my deep skin. The shade range alone deserves a standing ovation.",
  },
  {
    name: 'Sophie L.',
    shade: 'Shade 03 Shell',
    rating: 5,
    title: 'My skin, but better.',
    text: 'It looks like nothing is on my face but somehow all my redness is gone. The dewy finish is unreal. I wear it every single day.',
  },
  {
    name: 'Priya M.',
    shade: 'Shade 11 Amber',
    rating: 5,
    title: 'Worth every penny.',
    text: "I'm 42 and this is the only base product that doesn't settle into my fine lines. It's lightweight but covers everything I need it to.",
  },
];

const Reviews = () => {
  return (
    <section className="py-24 bg-rose-50/40">
      <div className="container mx-auto px-4 md:px-8">
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <div className="flex justify-center mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={20} className="fill-rose-400 text-rose-400" />
            ))}
          </div>
          <p className="text-sm tracking-widest uppercase text-neutral-500 mb-4">4.9 / 5 · 2,847 reviews</p>
          <h2 className="text-4xl md:text-5xl font-serif text-neutral-900">
            Loved by <span className="italic">everyone</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.15 }}
              className="bg-white p-8 flex flex-col"
            >
              <div className="flex mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <Star key={i} size={14} className="fill-rose-400 text-rose-400" />
                ))}
              </div>
              <h4 className="font-serif text-xl text-neutral-900 mb-3">{review.title}</h4>
              <p className="text-neutral-600 leading-relaxed mb-6 flex-1">"{review.text}"</p>
              <div className="border-t border-neutral-100 pt-4">
                <p className="text-sm font-medium text-neutral-900">{review.name}</p>
                <p className="text-xs text-neutral-400 tracking-wider uppercase mt-1">{review.shade}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
